import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { useTheme } from '../../../theme/ThemeProvider'
import { useStyles } from './EnterPhNo.styles'
import { SwText as Text } from '../../../components/common/SwText/SwText'
import { Image, View } from 'react-native'
import { ImageSource } from '../../../constants/images'
const EnterPhNo = () => {
    const {colors} = useTheme();
    const styles = useStyles(colors);
  return (
    <SafeAreaView edges={["bottom"]} style={styles.container} >
        <View>
            <Image source={ImageSource.banner} style={styles.banner} /> 
        </View>
        <View></View>
    </SafeAreaView>
  )
}

export default EnterPhNo;
