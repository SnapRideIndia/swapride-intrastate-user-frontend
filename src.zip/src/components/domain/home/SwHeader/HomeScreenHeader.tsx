import { Image, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../../../../theme/ThemeProvider';
import { useStyles } from './HomeScreenHeader.styles';
import { ImageSource } from '../../../../constants/images';
import { SwText as Text } from '../../../common/SwText/SwText';
import { useNavigation } from '@react-navigation/native';
import { ScreenNames } from '../../../../navigation/constant';
import { useSelector } from 'react-redux';
import { RootState } from '../../../../store';

const HomeScreenHeader = () => {
  const { colors } = useTheme();
  const styles = useStyles(colors);
  const navigation = useNavigation();
  const drawer = navigation.getParent();
  const {profileData} = useSelector((store: RootState)=>store.profile);

  const openDrawer = () => {
    if (drawer && 'openDrawer' in drawer) {
      (drawer as { openDrawer: () => void }).openDrawer();
    }
  };

  const handlePressbellIcon = () => {
    navigation.navigate(ScreenNames.NOTIFICATION_SCREEN as never);
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.innerContainer}>
        <TouchableOpacity onPress={openDrawer}>
          <Image source={ImageSource.menu} style={styles.menuIcon} />
        </TouchableOpacity>
        <TouchableOpacity onPress={handlePressbellIcon}>
          <Image source={ImageSource.bell} style={styles.bellIcon} />
        </TouchableOpacity>
      </View>
      <View style={[styles.innerContainer, { marginTop: 18, marginBottom: 14 }]}>
        <Text variant="medium" style={styles.greeting}>
          Good morning {profileData?.fullName?.split(" ")[0]},
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Image source={ImageSource.weather} style={styles.weatherIcon} />
          <Text variant="semi-bold" style={styles.tempText}>
            32c
          </Text>
          <Text variant="medium" style={styles.locationText}>
            Hyderabad
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default HomeScreenHeader;
