import { View, Image, TouchableOpacity } from 'react-native';
import { SwText as Text } from '../../../../components/common/SwText/SwText';
import React, { useState } from 'react';
import { useTheme } from '../../../../theme/ThemeProvider';
import { useStyles } from './RideDetails.styles';
import { ImageSource } from '../../../../constants/images';
import { Seperator } from '../../../common/Seperator/Seperator';
import { Point } from '../Point/Point';

export interface PointData {
  id?: string;
  time: string;
  title: string;
  description: string;
  images?: any[];
}

export interface RideDetailsProps {
  pickupData: PointData;
  dropoffData: PointData;
  onViewAllStops?: (defaultOpenStopId?: string) => void;
}

const RideDetails: React.FC<RideDetailsProps> = ({ pickupData, dropoffData, onViewAllStops }) => {
  const { colors } = useTheme();
  const styles = useStyles(colors);
  const [activeTab, setActiveTab] = useState<'pickup' | 'dropoff'>('pickup');

  const handleViewAllStops = () => {
    const stopId = activeTab === 'pickup' ? pickupData.id : dropoffData.id;
    onViewAllStops?.(stopId);
  };

  return (
    <View style={styles.container}>
      <View style={[styles.contentWrapper, styles.flexRow]}>
        <Text variant="bold" style={[styles.primaryFont, styles.title]}>
          Ride Details
        </Text>

        <View style={styles.shareContainer}>
          <Text variant="bold" style={[styles.primaryFont, styles.shareText]}>
            Share
          </Text>
          <Image source={ImageSource.shareBlue} style={styles.shareIcon} />
        </View>
      </View>

      {/* Tab Bar */}
      <View style={styles.tabContainer}>
        <View style={styles.tabsWrapper}>
          <TouchableOpacity onPress={() => setActiveTab('pickup')} style={styles.tabItem}>
            <Text
              variant={activeTab === 'pickup' ? 'bold' : 'medium'}
              style={[styles.tabText, activeTab === 'pickup' && styles.activeTabText]}
            >
              Pickup
            </Text>
            {activeTab === 'pickup' && <View style={styles.activeIndicator} />}
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setActiveTab('dropoff')} style={styles.tabItem}>
            <Text
              variant={activeTab === 'dropoff' ? 'bold' : 'medium'}
              style={[styles.tabText, activeTab === 'dropoff' && styles.activeTabText]}
            >
              Dropoff
            </Text>
            {activeTab === 'dropoff' && <View style={styles.activeIndicator} />}
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={handleViewAllStops} style={styles.viewAllStopsContainer}>
          <Text variant="bold" style={[styles.primaryFont, styles.viewAllStopsText]}>
            View all stops
          </Text>
          <Image source={ImageSource.chevron} style={styles.chevronIcon} />
        </TouchableOpacity>
      </View>

      <Seperator />

      {/* Tab Content */}
      <View style={styles.tabContentContainer}>
        {activeTab === 'pickup' ? (
          <Point
            time={pickupData.time}
            title={pickupData.title}
            description={pickupData.description}
            images={pickupData.images}
            onDirectionPress={() => {}}
          />
        ) : (
          <Point
            time={dropoffData.time}
            title={dropoffData.title}
            description={dropoffData.description}
            images={dropoffData.images}
            onDirectionPress={() => {}}
          />
        )}
      </View>
    </View>
  );
};

export default RideDetails;
