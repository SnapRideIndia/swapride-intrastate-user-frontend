import { StyleSheet } from 'react-native';
import { ColorsType } from '../../../constants/ui/colors/colors.types';

export const useStyles = (colors: ColorsType) =>
  StyleSheet.create({
    sheetBackground: {
      backgroundColor: colors.background_primary,
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
    },
    handleIndicator: {
      backgroundColor: colors.border_3,
      width: 40,
    },
    header: {
      paddingHorizontal: 16,
      paddingVertical: 14,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    title: {
      fontSize: 20,
      color: colors.contentPrimary,
      lineHeight: 20,
    },
    closeButton: {
      padding: 6,
    },
    closeIcon: {
      width: 18,
      height: 18,
      tintColor: colors.contentPrimary,
    },
    content: {
      paddingHorizontal: 16,
      paddingBottom: 8,
    },
    searchContainer: {
      height: 45,
      borderWidth: 0.4,
      borderColor: '#00000033',
      borderRadius: 15,
      paddingHorizontal: 12,
      // paddingVertical: 6,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: colors.background_primary,
      elevation: 2,
    },
    searchIcon: {
      width: 24,
      height: 24,
      tintColor: colors.contentPrimary,
    },
    searchInput: {
      flex: 1,
      paddingVertical: 0,
      color: colors.contentPrimary,
      fontSize: 16,
    },
    useCurrentLocationRow: {
      marginTop: 10,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 15,
      paddingVertical: 6,
    },
    useCurrentLocationIconWrap: {
      width: 45,
      height: 45,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#ECEFFA',
    },
    useCurrentLocationIcon: {
      width: 22,
      height: 22,
      tintColor: '#2F6BFF',
    },
    useCurrentLocationText: {
      fontSize: 14,
      color: '#1751BC',
    },
    divider: {
      height: StyleSheet.hairlineWidth,
      backgroundColor: colors.border_4,
      marginTop: 10,
    },
    sectionTitle: {
      marginTop: 23,
      marginBottom: 12,
      fontSize: 13,
      color: colors.contentPrimary,
      textTransform: 'lowercase',
    },
    emptyStateText: {
      fontSize: 12,
      color: colors.contenttertiary,
      marginTop: 6,
      marginBottom: 4,
      paddingLeft: 55, // aligns with text column after icon
    },
    listRow: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      gap: 10,
      paddingVertical: 10,
    },
    listRowMain: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
    },
    listIconWrap: {
      width: 45,
      height: 45,
      borderRadius: 999,
      backgroundColor: '#ECEFFA',
      alignItems: 'center',
      justifyContent: 'center',
    },
    listIcon: {
      width: 18,
      height: 18,
      tintColor: '#1751BC',
    },
    listTextWrap: {
      flex: 1,
      gap: 2,
    },
    listTitle: {
      fontSize: 14,
      color: colors.contentPrimary,
      lineHeight: 24,
    },
    listSubtitle: {
      fontSize: 12,
      color: colors.contenttertiary,
    },
    listRowBookmarkWrap: {
      alignSelf: 'center',
      padding: 8,
    },
    listRowBookmarkIcon: {
      width: 22,
      height: 22,
    },
    rowSeparator: {
      height: StyleSheet.hairlineWidth,
      backgroundColor: colors.border_4,
      marginLeft: 38,
    },
    // Container for results shown inline
    dropdownContainer: {
      marginTop: 10,
      borderRadius: 12,
      backgroundColor: colors.background_primary,
      overflow: 'hidden',
    },
    dropdownItem: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      paddingVertical: 12,
      paddingHorizontal: 14,
    },
    dropdownItemIcon: {
      width: 36,
      height: 36,
      borderRadius: 999,
      backgroundColor: '#ECEFFA',
      alignItems: 'center',
      justifyContent: 'center',
    },
    dropdownItemIconImg: {
      width: 20,
      height: 20,
      tintColor: '#1751BC',
    },
    dropdownItemTextWrap: {
      flex: 1,
    },
    dropdownItemTitle: {
      fontSize: 14,
      color: colors.contentPrimary,
      lineHeight: 20,
    },
    dropdownItemSubtitle: {
      fontSize: 12,
      color: colors.contenttertiary,
      marginTop: 2,
    },
    // Save Location (used inside SwPopupModal content)
    saveLocationFields: {
      marginTop: 0,
      gap: 2,
    },
    saveLocationFieldIcon: {
      width: 18,
      height: 18,
      tintColor: colors.contentPrimary,
    },
    saveLocationFieldIconLocation: {
      width: 16,
      height: 18,
      tintColor: colors.contentPrimary,
    },
    saveLocationButton: {
      marginTop: 14,
      alignSelf: 'stretch',
      backgroundColor: colors.primaryLight,
      elevation: 1,
      height: 44,
      shadowOpacity: 0,
      shadowRadius: 0,
      shadowOffset: { width: 0, height: 0 },
    },
    saveLocationButtonText: {
      color: colors.primaryCtaText,
    },
  });
