import { StyleSheet } from 'react-native';
import { ColorsType } from '../../../constants/Ui/colors/colors.types';
import { getFontFamilyByFW } from './SwText';

export const useStyles = (colors: ColorsType, varient: 'regular' | 'bold' | 'semi-bold' | 'medium') => StyleSheet.create({
    textStyle: {
        fontFamily: getFontFamilyByFW(varient),
        color: colors.contentPrimary,
        fontSize: 14
    }
});
