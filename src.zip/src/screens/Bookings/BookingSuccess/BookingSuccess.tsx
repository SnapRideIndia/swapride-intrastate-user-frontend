import React from 'react';
import { View, Image } from 'react-native';
import { useTheme } from '../../../theme/ThemeProvider';
import { useStyles } from './BookingSuccess.styles';
import { SwText as Text } from '../../../components/common/SwText/SwText';
import PrimaryButton from '../../../components/common/SwButton/PrimaryButton/PrimaryButton';
import PrimaryHeader from '../../../components/common/SwHeader/PrimaryHeader/PrimaryHeader';
import { ImageSource } from '../../../constants/images';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useRoute, RouteProp, CommonActions } from '@react-navigation/native';
import { RootStackParamList } from '../../../navigation/types';
import { ScreenNames } from '../../../navigation/constant';

const BookingSuccess = ({ navigation }: any) => {
  const { colors } = useTheme();
  const styles = useStyles(colors);
  const route = useRoute<RouteProp<RootStackParamList, typeof ScreenNames.BOOKING_SUCCESS>>();
  const { bookingId } = route.params;

  return (
    <View style={styles.container}>
      <PrimaryHeader title="" />

      <View style={styles.content}>
        <Image source={ImageSource.checkCircle} style={styles.successIcon} />
        <Text variant="bold" style={styles.title}>
          Ride Booked Successfully
        </Text>
        <Text style={styles.subtitle}>Your shuttle ride has been successfully booked.</Text>
      </View>

      <SafeAreaView edges={['bottom']} style={styles.footer}>
        <PrimaryButton
          title="View ticket"
          onPress={() =>
            navigation.dispatch(
              CommonActions.reset({
                index: 1,
                routes: [
                  { name: ScreenNames.DASHBOARD_SCREEN },
                  { name: ScreenNames.TICKET_DETAIL_SCREEN, params: { ticketId: bookingId } },
                ],
              }),
            )
          }
          btnStyle={styles.viewTicketBtn}
        />
        <PrimaryButton
          title="view ride"
          onPress={() =>
            navigation.dispatch(
              CommonActions.reset({
                index: 1,
                routes: [
                  { name: ScreenNames.DASHBOARD_SCREEN },
                  { name: ScreenNames.TRACK_RIDE_SCREEN, params: { ticketId: bookingId } },
                ],
              }),
            )
          }
          btnStyle={styles.viewRideBtn}
          textStyle={styles.viewRideBtnText}
        />
      </SafeAreaView>
    </View>
  );
};

export default BookingSuccess;
