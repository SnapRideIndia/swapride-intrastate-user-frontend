import HomeScreen from "../screens/home/HomeScreen/HomeScreen";

export const ScreenNames = {
    HOME_SCREEN: "HomeScreen"
}