import { useEffect, useState } from 'react';

export const useDebounce = <T,>(value: T, delayMs: number = 300): T => {
  const [debounced, setDebounced] = useState<T>(value);

  useEffect(() => {
    const id = setTimeout(() => {
      setDebounced(value);
    }, delayMs);

    return () => clearTimeout(id);
  }, [value, delayMs]);

  return debounced;
};

